# Платформа Печать аттестатов — API-сервис

Backend-сервис на **Java 21 / Spring Boot 3**, реализующий предметную область курсовой
работы: учёт учащихся, образовательных программ, итоговых отметок и жизненного цикла
печати аттестатов (DRAFT → VALIDATED → GENERATED → ISSUED / CANCELLED).

## Стек технологий

- Java 21, Spring Boot 3.3.4
- Spring Web, Spring Data JPA (Hibernate), Spring Security + JWT (jjwt)
- PostgreSQL (прод), H2 (профиль `local` для быстрого старта)
- OpenPDF — формирование PDF аттестатов
- MapStruct + Lombok
- springdoc-openapi (Swagger UI)

## Структура проекта

```
src/main/java/ru/education/certificateplatform/
  entity/       — JPA-сущности (Student, EducationProgram, Subject,
                  CurriculumSubject, FinalGrade, Certificate,
                  CertificateTemplate, User, Role, AuditLog, ValidationResult)
  repository/   — Spring Data JPA репозитории
  service/      — бизнес-логика (Auth, Student, Program, Grade,
                  Validation, Pdf, Certificate, Template, Audit)
  controller/   — REST-контроллеры
  dto/          — запросы/ответы (records)
  mapper/       — MapStruct мапперы entity <-> DTO
  security/     — JWT-провайдер, фильтр, UserDetailsService
  config/       — SecurityConfig, OpenApiConfig, DataInitializer
  exception/    — доменные исключения + GlobalExceptionHandler
```

## Сборка и запуск

Требуется Maven и JDK 21.

### Быстрый старт (без PostgreSQL, встроенная H2)

```bash
mvn spring-boot:run -Dspring-boot.run.profiles=local
```

### С PostgreSQL

1. Создайте базу данных `certificate_platform`.
2. Задайте переменные окружения (или отредактируйте `application.yml`):
   `DB_URL`, `DB_USERNAME`, `DB_PASSWORD`, `JWT_SECRET`.
3. Соберите и запустите:

```bash
mvn clean package -DskipTests
java -jar target/certificate-platform.jar
```

Сервис поднимется на `http://localhost:8080`.
Swagger UI: `http://localhost:8080/swagger-ui.html`.

При первом запуске автоматически создаётся пользователь-администратор:
`admin / admin12345` (роль `ADMIN`) — смените пароль после первого входа.

## Аутентификация

```
POST /api/auth/login       { "username": "admin", "password": "admin12345" }
POST /api/auth/refresh     { "refreshToken": "..." }
POST /api/auth/register    (только ADMIN) { "username", "password", "role" }
```

Полученный `accessToken` передаётся в заголовке `Authorization: Bearer <token>`.

## Роли

- `ADMIN` — полный доступ, управление пользователями, программами, шаблонами
- `OPERATOR` — ведение учащихся и итоговых отметок, создание аттестатов
- `VALIDATOR` — проверка данных перед печатью (`/validate`)
- `PRINTER` — формирование PDF и выдача аттестатов
- `MANAGER` — выдача/отмена аттестатов, просмотр журнала аудита

## Основные эндпоинты

```
/api/students            CRUD учащихся
/api/programs             CRUD образовательных программ и учебных планов
/api/grades/import        импорт итоговых отметок
/api/grades/student/{id}  отметки учащегося
/api/certificates          создание/список аттестатов
/api/certificates/{id}/validate    проверка данных перед печатью
/api/certificates/{id}/generate    формирование PDF
/api/certificates/{id}/issue       выдача аттестата
/api/certificates/{id}/cancel      отмена
/api/certificates/{id}/pdf         скачивание PDF
/api/templates             шаблоны аттестатов
/api/audit                 журнал аудита действий
```

## Жизненный цикл аттестата

```
DRAFT --validate--> VALIDATED --generate--> GENERATED --issue--> ISSUED
  \_________________________cancel____________________/
```

Формирование PDF (`/generate`) всегда повторно проверяет данные учащегося и
откажет (409, `VALIDATION_ERROR`), если не заполнены обязательные сведения или
отсутствуют/некорректны итоговые отметки по обязательным предметам программы.

Дополнительные эндпоинты: `/api/subjects` (каталог предметов) и `/api/users`
(управление учётными записями, только ADMIN).

## Запуск через Docker Compose

Поднимает сервис вместе с PostgreSQL:

```bash
docker compose up --build
```

Готовые примеры запросов — в файле `requests.http` (REST Client для VS Code
или IntelliJ HTTP Client): вход, создание программы, учащегося, импорт
отметок, полный цикл аттестата и скачивание PDF.

## Тесты

```bash
mvn test
```
