package ru.education.certificateplatform;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CertificatePlatformApplication {

    public static void main(String[] args) {
        SpringApplication.run(CertificatePlatformApplication.class, args);
    }
}
