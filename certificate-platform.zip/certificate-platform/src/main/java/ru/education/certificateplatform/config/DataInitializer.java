package ru.education.certificateplatform.config;

import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import ru.education.certificateplatform.entity.Role;
import ru.education.certificateplatform.repository.UserRepository;
import ru.education.certificateplatform.service.AuthService;

@Component
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final AuthService authService;

    @Override
    public void run(String... args) {
        if (!userRepository.existsByUsername("admin")) {
            authService.register("admin", "admin12345", Role.ADMIN);
        }
    }
}
