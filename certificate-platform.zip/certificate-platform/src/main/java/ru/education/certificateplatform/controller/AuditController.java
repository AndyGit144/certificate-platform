package ru.education.certificateplatform.controller;

import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import ru.education.certificateplatform.dto.audit.AuditLogResponse;
import ru.education.certificateplatform.mapper.AuditMapper;
import ru.education.certificateplatform.service.AuditService;

@RestController
@RequestMapping("/api/audit")
@RequiredArgsConstructor
@Tag(name = "Журнал аудита")
@PreAuthorize("hasAnyRole('ADMIN','MANAGER')")
public class AuditController {

    private final AuditService auditService;
    private final AuditMapper auditMapper;

    @GetMapping
    public Page<AuditLogResponse> findAll(@RequestParam(defaultValue = "0") int page,
                                           @RequestParam(defaultValue = "50") int size) {
        return auditService.findAll(PageRequest.of(page, size)).map(auditMapper::toResponse);
    }

    @GetMapping("/entity")
    public Page<AuditLogResponse> findByEntity(@RequestParam String entityType,
                                                @RequestParam String entityId,
                                                @RequestParam(defaultValue = "0") int page,
                                                @RequestParam(defaultValue = "50") int size) {
        return auditService.findByEntity(entityType, entityId, PageRequest.of(page, size)).map(auditMapper::toResponse);
    }
}
