package ru.education.certificateplatform.controller;

import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import ru.education.certificateplatform.dto.certificate.CertificateCreateRequest;
import ru.education.certificateplatform.dto.certificate.CertificateResponse;
import ru.education.certificateplatform.dto.certificate.ValidationResultResponse;
import ru.education.certificateplatform.entity.Certificate;
import ru.education.certificateplatform.mapper.CertificateMapper;
import ru.education.certificateplatform.service.CertificateService;

import java.io.File;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/certificates")
@RequiredArgsConstructor
@Tag(name = "Аттестаты")
public class CertificateController {

    private final CertificateService certificateService;
    private final CertificateMapper certificateMapper;

    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN','OPERATOR','VALIDATOR','PRINTER','MANAGER')")
    public List<CertificateResponse> findAll() {
        return certificateService.findAll().stream().map(certificateMapper::toResponse).toList();
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','OPERATOR','VALIDATOR','PRINTER','MANAGER')")
    public CertificateResponse getById(@PathVariable UUID id) {
        return certificateMapper.toResponse(certificateService.getById(id));
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('ADMIN','OPERATOR')")
    public ResponseEntity<CertificateResponse> create(@Valid @RequestBody CertificateCreateRequest request) {
        Certificate created = certificateService.create(request);
        return ResponseEntity.status(201).body(certificateMapper.toResponse(created));
    }

    @PostMapping("/{id}/validate")
    @PreAuthorize("hasAnyRole('ADMIN','VALIDATOR')")
    public ValidationResultResponse validate(@PathVariable UUID id) {
        var result = certificateService.validate(id);
        return new ValidationResultResponse(!result.hasErrors(), result.errors(), result.warnings());
    }

    @PostMapping("/{id}/generate")
    @PreAuthorize("hasAnyRole('ADMIN','PRINTER')")
    public CertificateResponse generate(@PathVariable UUID id) {
        return certificateMapper.toResponse(certificateService.generate(id));
    }

    @PostMapping("/{id}/issue")
    @PreAuthorize("hasAnyRole('ADMIN','PRINTER','MANAGER')")
    public CertificateResponse issue(@PathVariable UUID id) {
        return certificateMapper.toResponse(certificateService.issue(id));
    }

    @PostMapping("/{id}/cancel")
    @PreAuthorize("hasAnyRole('ADMIN','MANAGER')")
    public CertificateResponse cancel(@PathVariable UUID id, @RequestParam(required = false) String reason) {
        return certificateMapper.toResponse(certificateService.cancel(id, reason));
    }

    @GetMapping("/{id}/pdf")
    @PreAuthorize("hasAnyRole('ADMIN','OPERATOR','VALIDATOR','PRINTER','MANAGER')")
    public ResponseEntity<FileSystemResource> downloadPdf(@PathVariable UUID id) {
        Certificate certificate = certificateService.getById(id);
        if (certificate.getPdfPath() == null) {
            return ResponseEntity.notFound().build();
        }
        File file = new File(certificate.getPdfPath());
        return ResponseEntity.ok()
                .contentType(MediaType.APPLICATION_PDF)
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + file.getName() + "\"")
                .body(new FileSystemResource(file));
    }
}
