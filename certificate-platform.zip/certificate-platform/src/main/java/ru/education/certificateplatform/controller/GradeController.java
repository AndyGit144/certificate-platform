package ru.education.certificateplatform.controller;

import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import ru.education.certificateplatform.dto.grade.GradeImportRequest;
import ru.education.certificateplatform.dto.grade.GradeResponse;
import ru.education.certificateplatform.dto.grade.GradeUpdateRequest;
import ru.education.certificateplatform.mapper.GradeMapper;
import ru.education.certificateplatform.service.GradeService;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/grades")
@RequiredArgsConstructor
@Tag(name = "Итоговые отметки")
public class GradeController {

    private final GradeService gradeService;
    private final GradeMapper gradeMapper;

    @PostMapping("/import")
    @PreAuthorize("hasAnyRole('ADMIN','OPERATOR')")
    public List<GradeResponse> importGrades(@Valid @RequestBody GradeImportRequest request) {
        return gradeService.importGrades(request).stream().map(gradeMapper::toResponse).toList();
    }

    @GetMapping("/student/{studentId}")
    @PreAuthorize("hasAnyRole('ADMIN','OPERATOR','VALIDATOR','PRINTER','MANAGER')")
    public List<GradeResponse> findByStudent(@PathVariable UUID studentId) {
        return gradeService.findByStudent(studentId).stream().map(gradeMapper::toResponse).toList();
    }

    @PutMapping("/{gradeId}")
    @PreAuthorize("hasAnyRole('ADMIN','OPERATOR')")
    public GradeResponse update(@PathVariable UUID gradeId, @Valid @RequestBody GradeUpdateRequest request) {
        return gradeMapper.toResponse(gradeService.updateGrade(gradeId, request.gradeValue()));
    }
}
