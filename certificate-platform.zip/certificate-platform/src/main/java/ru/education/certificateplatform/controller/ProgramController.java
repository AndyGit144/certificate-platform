package ru.education.certificateplatform.controller;

import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import ru.education.certificateplatform.dto.program.ProgramCreateRequest;
import ru.education.certificateplatform.dto.program.ProgramResponse;
import ru.education.certificateplatform.mapper.ProgramMapper;
import ru.education.certificateplatform.service.ProgramService;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/programs")
@RequiredArgsConstructor
@Tag(name = "Образовательные программы")
public class ProgramController {

    private final ProgramService programService;
    private final ProgramMapper programMapper;

    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN','OPERATOR','VALIDATOR','PRINTER','MANAGER')")
    public List<ProgramResponse> findAll() {
        return programService.findAll().stream().map(programMapper::toResponse).toList();
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','OPERATOR','VALIDATOR','PRINTER','MANAGER')")
    public ProgramResponse getById(@PathVariable UUID id) {
        return programMapper.toResponse(programService.getById(id));
    }

    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ProgramResponse> create(@Valid @RequestBody ProgramCreateRequest request) {
        var created = programService.create(request);
        return ResponseEntity.status(201).body(programMapper.toResponse(created));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Void> delete(@PathVariable UUID id) {
        programService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
