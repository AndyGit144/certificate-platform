package ru.education.certificateplatform.controller;

import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import ru.education.certificateplatform.dto.student.StudentCreateRequest;
import ru.education.certificateplatform.dto.student.StudentResponse;
import ru.education.certificateplatform.dto.student.StudentUpdateRequest;
import ru.education.certificateplatform.mapper.StudentMapper;
import ru.education.certificateplatform.service.StudentService;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/students")
@RequiredArgsConstructor
@Tag(name = "Учащиеся")
public class StudentController {

    private final StudentService studentService;
    private final StudentMapper studentMapper;

    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN','OPERATOR','VALIDATOR','PRINTER','MANAGER')")
    public List<StudentResponse> findAll(@RequestParam(defaultValue = "false") boolean includeArchived) {
        return studentService.findAll(includeArchived).stream().map(studentMapper::toResponse).toList();
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','OPERATOR','VALIDATOR','PRINTER','MANAGER')")
    public StudentResponse getById(@PathVariable UUID id) {
        return studentMapper.toResponse(studentService.getById(id));
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('ADMIN','OPERATOR')")
    public ResponseEntity<StudentResponse> create(@Valid @RequestBody StudentCreateRequest request) {
        var created = studentService.create(request);
        return ResponseEntity.status(201).body(studentMapper.toResponse(created));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','OPERATOR')")
    public StudentResponse update(@PathVariable UUID id, @Valid @RequestBody StudentUpdateRequest request) {
        return studentMapper.toResponse(studentService.update(id, request));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','OPERATOR')")
    public ResponseEntity<Void> archive(@PathVariable UUID id) {
        studentService.archive(id);
        return ResponseEntity.noContent().build();
    }
}
