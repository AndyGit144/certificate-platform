package ru.education.certificateplatform.controller;

import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import ru.education.certificateplatform.entity.Subject;
import ru.education.certificateplatform.repository.SubjectRepository;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/subjects")
@RequiredArgsConstructor
@Tag(name = "Предметы")
public class SubjectController {

    private final SubjectRepository subjectRepository;

    public record SubjectRequest(@NotBlank String name) {}
    public record SubjectResponse(UUID id, String name) {}

    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN','OPERATOR','VALIDATOR','PRINTER','MANAGER')")
    public List<SubjectResponse> findAll() {
        return subjectRepository.findAll().stream()
                .map(s -> new SubjectResponse(s.getId(), s.getName()))
                .toList();
    }

    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<SubjectResponse> create(@Valid @RequestBody SubjectRequest request) {
        Subject saved = subjectRepository.findByName(request.name())
                .orElseGet(() -> subjectRepository.save(Subject.builder().name(request.name()).build()));
        return ResponseEntity.status(201).body(new SubjectResponse(saved.getId(), saved.getName()));
    }
}
