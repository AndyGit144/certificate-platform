package ru.education.certificateplatform.controller;

import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import ru.education.certificateplatform.dto.certificate.TemplateCreateRequest;
import ru.education.certificateplatform.dto.certificate.TemplateResponse;
import ru.education.certificateplatform.mapper.CertificateMapper;
import ru.education.certificateplatform.service.TemplateService;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/templates")
@RequiredArgsConstructor
@Tag(name = "Шаблоны аттестатов")
public class TemplateController {

    private final TemplateService templateService;
    private final CertificateMapper certificateMapper;

    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN','PRINTER','MANAGER')")
    public List<TemplateResponse> findAll() {
        return templateService.findAll().stream().map(certificateMapper::toResponse).toList();
    }

    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<TemplateResponse> create(@Valid @RequestBody TemplateCreateRequest request) {
        var created = templateService.create(request);
        return ResponseEntity.status(201).body(certificateMapper.toResponse(created));
    }

    @PostMapping("/{id}/activate")
    @PreAuthorize("hasRole('ADMIN')")
    public TemplateResponse activate(@PathVariable UUID id) {
        return certificateMapper.toResponse(templateService.activate(id));
    }
}
