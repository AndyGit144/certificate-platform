package ru.education.certificateplatform.controller;

import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import ru.education.certificateplatform.dto.auth.UserProfileResponse;
import ru.education.certificateplatform.service.UserManagementService;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
@Tag(name = "Пользователи")
@PreAuthorize("hasRole('ADMIN')")
public class UserController {

    private final UserManagementService userManagementService;

    @GetMapping
    public List<UserProfileResponse> findAll() {
        return userManagementService.findAll().stream()
                .map(u -> new UserProfileResponse(u.getId(), u.getUsername(), u.getRole().name()))
                .toList();
    }

    @PostMapping("/{id}/deactivate")
    public UserProfileResponse deactivate(@PathVariable UUID id) {
        var u = userManagementService.setActive(id, false);
        return new UserProfileResponse(u.getId(), u.getUsername(), u.getRole().name());
    }

    @PostMapping("/{id}/activate")
    public UserProfileResponse activate(@PathVariable UUID id) {
        var u = userManagementService.setActive(id, true);
        return new UserProfileResponse(u.getId(), u.getUsername(), u.getRole().name());
    }
}
