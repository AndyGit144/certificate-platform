package ru.education.certificateplatform.dto;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Единый формат ответа об ошибке для всего REST API,
 * согласно контракту, описанному в разделе 2.5 курсовой работы.
 */
public record ErrorResponse(
        String code,
        String message,
        List<String> details,
        LocalDateTime timestamp
) {
    public ErrorResponse(String code, String message, List<String> details) {
        this(code, message, details, LocalDateTime.now());
    }
}
