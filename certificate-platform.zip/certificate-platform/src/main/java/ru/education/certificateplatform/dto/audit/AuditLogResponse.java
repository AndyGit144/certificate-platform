package ru.education.certificateplatform.dto.audit;

import java.time.LocalDateTime;
import java.util.UUID;

public record AuditLogResponse(
        UUID id,
        String username,
        String action,
        String entityType,
        String entityId,
        LocalDateTime timestamp,
        String details
) {}
