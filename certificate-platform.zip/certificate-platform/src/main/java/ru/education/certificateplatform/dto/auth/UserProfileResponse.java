package ru.education.certificateplatform.dto.auth;

import java.util.UUID;

public record UserProfileResponse(
        UUID id,
        String username,
        String role
) {}
