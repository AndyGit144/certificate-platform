package ru.education.certificateplatform.dto.certificate;

import jakarta.validation.constraints.NotNull;

import java.util.UUID;

public record CertificateCreateRequest(
        @NotNull UUID studentId,
        @NotNull UUID templateId
) {}
