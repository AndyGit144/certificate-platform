package ru.education.certificateplatform.dto.certificate;

import java.time.LocalDateTime;
import java.util.UUID;

public record CertificateResponse(
        UUID id,
        UUID studentId,
        String studentFullName,
        String certificateNumber,
        String status,
        LocalDateTime generatedAt,
        LocalDateTime issuedAt,
        String pdfUrl
) {}
