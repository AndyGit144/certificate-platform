package ru.education.certificateplatform.dto.certificate;

import jakarta.validation.constraints.NotBlank;

public record TemplateCreateRequest(
        @NotBlank String name,
        String layoutPath
) {}
