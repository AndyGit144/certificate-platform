package ru.education.certificateplatform.dto.certificate;

import java.util.UUID;

public record TemplateResponse(
        UUID id,
        String name,
        int version,
        boolean active,
        String layoutPath
) {}
