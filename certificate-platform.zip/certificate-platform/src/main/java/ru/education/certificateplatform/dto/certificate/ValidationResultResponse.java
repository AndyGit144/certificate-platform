package ru.education.certificateplatform.dto.certificate;

import java.util.List;

public record ValidationResultResponse(
        boolean valid,
        List<String> errors,
        List<String> warnings
) {}
