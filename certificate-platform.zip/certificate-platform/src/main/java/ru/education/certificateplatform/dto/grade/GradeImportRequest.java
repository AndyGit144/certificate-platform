package ru.education.certificateplatform.dto.grade;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

import java.util.List;
import java.util.UUID;

public record GradeImportRequest(
        @NotNull UUID studentId,
        @NotEmpty List<GradeItem> grades
) {
    public record GradeItem(
            @NotNull UUID subjectId,
            @NotBlank String gradeValue
    ) {}
}
