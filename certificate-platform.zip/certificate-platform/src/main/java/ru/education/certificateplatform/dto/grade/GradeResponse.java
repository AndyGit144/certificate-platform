package ru.education.certificateplatform.dto.grade;

import java.util.UUID;

public record GradeResponse(
        UUID id,
        UUID studentId,
        UUID subjectId,
        String subjectName,
        String gradeValue
) {}
