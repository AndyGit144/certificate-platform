package ru.education.certificateplatform.dto.grade;

import jakarta.validation.constraints.NotBlank;

public record GradeUpdateRequest(@NotBlank String gradeValue) {}
