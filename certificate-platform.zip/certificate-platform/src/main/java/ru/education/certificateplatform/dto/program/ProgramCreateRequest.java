package ru.education.certificateplatform.dto.program;

import jakarta.validation.constraints.NotBlank;

import java.util.List;
import java.util.UUID;

public record ProgramCreateRequest(
        @NotBlank String name,
        @NotBlank String level,
        List<CurriculumSubjectRequest> subjects
) {
    public record CurriculumSubjectRequest(
            UUID subjectId,
            String subjectName,
            boolean mandatory,
            int displayOrder
    ) {}
}
