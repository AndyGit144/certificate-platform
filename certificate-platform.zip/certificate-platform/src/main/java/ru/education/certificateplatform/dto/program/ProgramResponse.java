package ru.education.certificateplatform.dto.program;

import java.util.List;
import java.util.UUID;

public record ProgramResponse(
        UUID id,
        String name,
        String level,
        List<SubjectItem> subjects
) {
    public record SubjectItem(
            UUID subjectId,
            String subjectName,
            boolean mandatory,
            int displayOrder
    ) {}
}
