package ru.education.certificateplatform.dto.student;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Past;

import java.time.LocalDate;
import java.util.UUID;

public record StudentCreateRequest(
        @NotBlank String lastName,
        @NotBlank String firstName,
        String middleName,
        @NotNull @Past LocalDate birthDate,
        @NotBlank String personalNumber,
        @NotNull UUID programId
) {}
