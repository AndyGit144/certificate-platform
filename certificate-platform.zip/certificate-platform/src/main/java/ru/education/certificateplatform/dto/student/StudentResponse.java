package ru.education.certificateplatform.dto.student;

import java.time.LocalDate;
import java.util.UUID;

public record StudentResponse(
        UUID id,
        String lastName,
        String firstName,
        String middleName,
        LocalDate birthDate,
        String personalNumber,
        boolean archived,
        UUID programId,
        String programName
) {}
