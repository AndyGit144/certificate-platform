package ru.education.certificateplatform.dto.student;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.time.LocalDate;
import java.util.UUID;

public record StudentUpdateRequest(
        @NotBlank String lastName,
        @NotBlank String firstName,
        String middleName,
        @NotNull LocalDate birthDate,
        @NotNull UUID programId
) {}
