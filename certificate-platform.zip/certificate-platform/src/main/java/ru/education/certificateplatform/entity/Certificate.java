package ru.education.certificateplatform.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "certificates")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Certificate {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @OneToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "student_id", unique = true)
    private Student student;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "template_id")
    private CertificateTemplate template;

    @Column(nullable = false, unique = true, length = 50)
    private String certificateNumber;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private CertificateStatus status;

    private LocalDateTime generatedAt;
    private LocalDateTime issuedAt;

    @Column(length = 500)
    private String pdfPath;

    public boolean canBeValidated() {
        return status == CertificateStatus.DRAFT;
    }

    public boolean canBeGenerated() {
        return status == CertificateStatus.DRAFT || status == CertificateStatus.VALIDATED;
    }

    public boolean canBeIssued() {
        return status == CertificateStatus.GENERATED;
    }

    public boolean canBeCancelled() {
        return status != CertificateStatus.ISSUED && status != CertificateStatus.CANCELLED;
    }

    public void markValidated() {
        this.status = CertificateStatus.VALIDATED;
    }

    public void markGenerated(String pdfPath) {
        this.pdfPath = pdfPath;
        this.generatedAt = LocalDateTime.now();
        this.status = CertificateStatus.GENERATED;
    }

    public void markIssued() {
        this.issuedAt = LocalDateTime.now();
        this.status = CertificateStatus.ISSUED;
    }

    public void markCancelled() {
        this.status = CertificateStatus.CANCELLED;
    }
}
