package ru.education.certificateplatform.entity;

/**
 * Жизненный цикл аттестата: DRAFT -> VALIDATED -> GENERATED -> ISSUED,
 * с возможным переходом в CANCELLED из состояний, отличных от ISSUED.
 */
public enum CertificateStatus {
    DRAFT,
    VALIDATED,
    GENERATED,
    ISSUED,
    CANCELLED
}
