package ru.education.certificateplatform.entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.UUID;

/**
 * Связь предмета с образовательной программой и параметрами
 * его отражения в аттестате (обязательность, порядок вывода).
 */
@Entity
@Table(name = "curriculum_subjects")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CurriculumSubject {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "program_id")
    private EducationProgram program;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "subject_id")
    private Subject subject;

    @Column(nullable = false)
    @Builder.Default
    private boolean mandatory = true;

    @Column(nullable = false)
    private int displayOrder;
}
