package ru.education.certificateplatform.entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Entity
@Table(name = "education_programs")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EducationProgram {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(nullable = false, length = 200)
    private String name;

    @Column(nullable = false, length = 20)
    private String level; // например: "среднее общее", "основное общее"

    @OneToMany(mappedBy = "program", cascade = CascadeType.ALL, orphanRemoval = true)
    @Builder.Default
    private List<CurriculumSubject> curriculumSubjects = new ArrayList<>();
}
