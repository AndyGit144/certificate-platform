package ru.education.certificateplatform.entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.UUID;

@Entity
@Table(name = "final_grades", uniqueConstraints = {
        @UniqueConstraint(columnNames = {"student_id", "subject_id"})
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FinalGrade {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "student_id")
    private Student student;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "subject_id")
    private Subject subject;

    /**
     * Значение отметки в текстовом виде, поскольку порядок заполнения
     * аттестатов допускает как числовые баллы ("5"), так и служебные
     * обозначения ("зачет", "освобожден").
     */
    @Column(nullable = false, length = 20)
    private String gradeValue;

    private static final java.util.Set<String> ALLOWED_VALUES = java.util.Set.of(
            "2", "3", "4", "5", "зачет", "освобожден"
    );

    public boolean isValueAllowed() {
        return gradeValue != null && ALLOWED_VALUES.contains(gradeValue.trim().toLowerCase());
    }
}
