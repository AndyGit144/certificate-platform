package ru.education.certificateplatform.entity;

/**
 * Роли пользователей подсистемы печати аттестатов.
 * Используются как в Spring Security (ROLE_*), так и в бизнес-логике.
 */
public enum Role {
    ADMIN,      // Администратор
    OPERATOR,   // Оператор учебной части
    VALIDATOR,  // Проверяющий
    PRINTER,    // Ответственный за печать
    MANAGER     // Руководитель / контролер
}
