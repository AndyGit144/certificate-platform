package ru.education.certificateplatform.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;
import java.util.UUID;

@Entity
@Table(name = "students")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Student {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(nullable = false, length = 100)
    private String lastName;

    @Column(nullable = false, length = 100)
    private String firstName;

    @Column(length = 100)
    private String middleName;

    @Column(nullable = false)
    private LocalDate birthDate;

    @Column(nullable = false, unique = true, length = 30)
    private String personalNumber;

    @Column(nullable = false)
    @Builder.Default
    private boolean archived = false;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "program_id")
    private EducationProgram program;

    /**
     * Проверка наличия обязательных персональных сведений
     * согласно требованиям порядка заполнения аттестатов.
     */
    public boolean hasCompletePersonalData() {
        return lastName != null && !lastName.isBlank()
                && firstName != null && !firstName.isBlank()
                && birthDate != null
                && personalNumber != null && !personalNumber.isBlank()
                && program != null;
    }

    public String fullName() {
        StringBuilder sb = new StringBuilder();
        sb.append(lastName).append(' ').append(firstName);
        if (middleName != null && !middleName.isBlank()) {
            sb.append(' ').append(middleName);
        }
        return sb.toString();
    }
}
