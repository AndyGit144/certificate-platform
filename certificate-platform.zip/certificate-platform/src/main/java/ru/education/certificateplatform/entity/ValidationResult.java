package ru.education.certificateplatform.entity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Результат проверки данных перед печатью аттестата.
 * Разделяет диагностику на ошибки (блокируют генерацию) и
 * предупреждения (фиксируются, но не останавливают процесс).
 */
public class ValidationResult {

    private final List<String> errors = new ArrayList<>();
    private final List<String> warnings = new ArrayList<>();

    public void addError(String message) {
        errors.add(message);
    }

    public void addWarning(String message) {
        warnings.add(message);
    }

    public boolean hasErrors() {
        return !errors.isEmpty();
    }

    public List<String> errors() {
        return Collections.unmodifiableList(errors);
    }

    public List<String> warnings() {
        return Collections.unmodifiableList(warnings);
    }
}
