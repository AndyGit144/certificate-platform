package ru.education.certificateplatform.mapper;

import org.mapstruct.Mapper;
import ru.education.certificateplatform.dto.audit.AuditLogResponse;
import ru.education.certificateplatform.entity.AuditLog;

@Mapper(componentModel = "spring")
public interface AuditMapper {

    AuditLogResponse toResponse(AuditLog auditLog);
}
