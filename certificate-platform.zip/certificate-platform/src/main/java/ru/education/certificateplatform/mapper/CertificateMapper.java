package ru.education.certificateplatform.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import ru.education.certificateplatform.dto.certificate.CertificateResponse;
import ru.education.certificateplatform.dto.certificate.TemplateResponse;
import ru.education.certificateplatform.entity.Certificate;
import ru.education.certificateplatform.entity.CertificateTemplate;

@Mapper(componentModel = "spring")
public interface CertificateMapper {

    @Mapping(target = "studentId", source = "student.id")
    @Mapping(target = "studentFullName", expression = "java(certificate.getStudent().fullName())")
    @Mapping(target = "status", expression = "java(certificate.getStatus().name())")
    @Mapping(target = "pdfUrl", source = "pdfPath")
    CertificateResponse toResponse(Certificate certificate);

    TemplateResponse toResponse(CertificateTemplate template);
}
