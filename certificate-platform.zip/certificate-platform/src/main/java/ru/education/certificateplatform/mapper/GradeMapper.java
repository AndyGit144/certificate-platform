package ru.education.certificateplatform.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import ru.education.certificateplatform.dto.grade.GradeResponse;
import ru.education.certificateplatform.entity.FinalGrade;

@Mapper(componentModel = "spring")
public interface GradeMapper {

    @Mapping(target = "studentId", source = "student.id")
    @Mapping(target = "subjectId", source = "subject.id")
    @Mapping(target = "subjectName", source = "subject.name")
    GradeResponse toResponse(FinalGrade grade);
}
