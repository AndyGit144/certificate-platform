package ru.education.certificateplatform.mapper;

import org.mapstruct.Mapper;
import ru.education.certificateplatform.dto.program.ProgramResponse;
import ru.education.certificateplatform.entity.CurriculumSubject;
import ru.education.certificateplatform.entity.EducationProgram;

import java.util.List;

@Mapper(componentModel = "spring")
public interface ProgramMapper {

    default ProgramResponse toResponse(EducationProgram program) {
        List<ProgramResponse.SubjectItem> items = program.getCurriculumSubjects().stream()
                .map(this::toItem)
                .toList();
        return new ProgramResponse(program.getId(), program.getName(), program.getLevel(), items);
    }

    default ProgramResponse.SubjectItem toItem(CurriculumSubject cs) {
        return new ProgramResponse.SubjectItem(
                cs.getSubject().getId(),
                cs.getSubject().getName(),
                cs.isMandatory(),
                cs.getDisplayOrder());
    }
}
