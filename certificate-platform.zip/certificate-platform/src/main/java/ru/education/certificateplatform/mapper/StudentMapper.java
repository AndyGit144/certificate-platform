package ru.education.certificateplatform.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import ru.education.certificateplatform.dto.student.StudentResponse;
import ru.education.certificateplatform.entity.Student;

@Mapper(componentModel = "spring")
public interface StudentMapper {

    @Mapping(target = "programId", source = "program.id")
    @Mapping(target = "programName", source = "program.name")
    StudentResponse toResponse(Student student);
}
