package ru.education.certificateplatform.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import ru.education.certificateplatform.entity.Certificate;

import java.util.Optional;
import java.util.UUID;

@Repository
public interface CertificateRepository extends JpaRepository<Certificate, UUID> {

    Optional<Certificate> findByStudentId(UUID studentId);

    boolean existsByStudentId(UUID studentId);

    boolean existsByCertificateNumber(String certificateNumber);

    long countByCertificateNumberStartingWith(String prefix);
}
