package ru.education.certificateplatform.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import ru.education.certificateplatform.entity.CurriculumSubject;

import java.util.List;
import java.util.UUID;

@Repository
public interface CurriculumSubjectRepository extends JpaRepository<CurriculumSubject, UUID> {

    List<CurriculumSubject> findByProgramIdOrderByDisplayOrderAsc(UUID programId);

    void deleteByProgramId(UUID programId);
}
