package ru.education.certificateplatform.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import ru.education.certificateplatform.entity.FinalGrade;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface FinalGradeRepository extends JpaRepository<FinalGrade, UUID> {

    List<FinalGrade> findByStudentId(UUID studentId);

    Optional<FinalGrade> findByStudentIdAndSubjectId(UUID studentId, UUID subjectId);

    boolean existsByStudentIdAndSubjectId(UUID studentId, UUID subjectId);
}
