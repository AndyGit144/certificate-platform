package ru.education.certificateplatform.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import ru.education.certificateplatform.entity.EducationProgram;

import java.util.UUID;

@Repository
public interface ProgramRepository extends JpaRepository<EducationProgram, UUID> {
}
