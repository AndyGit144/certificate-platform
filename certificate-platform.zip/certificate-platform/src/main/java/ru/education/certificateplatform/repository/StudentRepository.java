package ru.education.certificateplatform.repository;

import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import ru.education.certificateplatform.entity.Student;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface StudentRepository extends JpaRepository<Student, UUID> {

    Optional<Student> findByPersonalNumber(String personalNumber);

    boolean existsByPersonalNumber(String personalNumber);

    @EntityGraph(attributePaths = {"program"})
    Optional<Student> findWithProgramById(UUID id);

    List<Student> findByArchivedFalse();
}
