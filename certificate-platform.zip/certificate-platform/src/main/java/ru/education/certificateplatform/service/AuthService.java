package ru.education.certificateplatform.service;

import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.education.certificateplatform.dto.auth.LoginRequest;
import ru.education.certificateplatform.dto.auth.TokenResponse;
import ru.education.certificateplatform.entity.Role;
import ru.education.certificateplatform.entity.User;
import ru.education.certificateplatform.exception.DuplicateEntityException;
import ru.education.certificateplatform.exception.EntityNotFoundException;
import ru.education.certificateplatform.repository.UserRepository;
import ru.education.certificateplatform.security.JwtTokenProvider;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final AuthenticationManager authenticationManager;
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtTokenProvider tokenProvider;
    private final AuditService auditService;

    @Transactional(readOnly = true)
    public TokenResponse login(LoginRequest request) {
        try {
            authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(request.username(), request.password()));
        } catch (BadCredentialsException ex) {
            auditService.log("LOGIN_FAILED", "User", request.username(), "Неверные учетные данные");
            throw ex;
        }

        User user = userRepository.findByUsername(request.username())
                .orElseThrow(() -> new BadCredentialsException("Неверное имя пользователя или пароль"));

        auditService.log("LOGIN_SUCCESS", "User", user.getId().toString(), null);
        return TokenResponse.bearer(
                tokenProvider.generateAccessToken(user.getUsername(), user.getRole().name()),
                tokenProvider.generateRefreshToken(user.getUsername(), user.getRole().name()));
    }

    @Transactional(readOnly = true)
    public TokenResponse refresh(String refreshToken) {
        if (!tokenProvider.isValid(refreshToken) || !tokenProvider.isRefreshToken(refreshToken)) {
            throw new BadCredentialsException("Недействительный refresh-токен");
        }
        String username = tokenProvider.extractUsername(refreshToken);
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new EntityNotFoundException("Пользователь не найден"));
        if (!user.isActive()) {
            throw new BadCredentialsException("Учетная запись деактивирована");
        }
        return TokenResponse.bearer(
                tokenProvider.generateAccessToken(user.getUsername(), user.getRole().name()),
                tokenProvider.generateRefreshToken(user.getUsername(), user.getRole().name()));
    }

    @Transactional
    public User register(String username, String rawPassword, Role role) {
        if (userRepository.existsByUsername(username)) {
            throw new DuplicateEntityException("Пользователь с таким именем уже существует: " + username);
        }
        User user = User.builder()
                .username(username)
                .passwordHash(passwordEncoder.encode(rawPassword))
                .role(role)
                .active(true)
                .build();
        User saved = userRepository.save(user);
        auditService.log("USER_CREATED", "User", saved.getId().toString(), "role=" + role);
        return saved;
    }
}
