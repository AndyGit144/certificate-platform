package ru.education.certificateplatform.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.education.certificateplatform.dto.certificate.CertificateCreateRequest;
import ru.education.certificateplatform.entity.*;
import ru.education.certificateplatform.exception.DuplicateEntityException;
import ru.education.certificateplatform.exception.EntityNotFoundException;
import ru.education.certificateplatform.exception.ForbiddenOperationException;
import ru.education.certificateplatform.exception.ValidationException;
import ru.education.certificateplatform.repository.CertificateRepository;

import java.time.Year;
import java.util.List;
import java.util.UUID;

/**
 * Управляет жизненным циклом аттестата: создание черновика,
 * проверка данных, формирование PDF, выдача и отмена.
 */
@Service
@RequiredArgsConstructor
public class CertificateService {

    private final CertificateRepository certificateRepository;
    private final StudentService studentService;
    private final TemplateService templateService;
    private final ValidationService validationService;
    private final PdfService pdfService;
    private final AuditService auditService;

    @Transactional
    public Certificate create(CertificateCreateRequest request) {
        Student student = studentService.getById(request.studentId());
        if (certificateRepository.existsByStudentId(student.getId())) {
            throw new DuplicateEntityException("Для учащегося уже создан аттестат");
        }
        CertificateTemplate template = templateService.getById(request.templateId());

        Certificate certificate = Certificate.builder()
                .student(student)
                .template(template)
                .certificateNumber(generateCertificateNumber())
                .status(CertificateStatus.DRAFT)
                .build();

        Certificate saved = certificateRepository.save(certificate);
        auditService.log("CERTIFICATE_CREATED", "Certificate", saved.getId().toString(), saved.getCertificateNumber());
        return saved;
    }

    private String generateCertificateNumber() {
        String prefix = Year.now().getValue() + "-";
        long count = certificateRepository.countByCertificateNumberStartingWith(prefix);
        String candidate;
        do {
            count++;
            candidate = prefix + String.format("%06d", count);
        } while (certificateRepository.existsByCertificateNumber(candidate));
        return candidate;
    }

    @Transactional
    public ValidationResult validate(UUID certificateId) {
        Certificate certificate = getById(certificateId);
        if (!certificate.canBeValidated()) {
            throw new ForbiddenOperationException("Проверка доступна только для аттестата в статусе DRAFT");
        }
        ValidationResult result = validationService.validate(certificate.getStudent());
        if (!result.hasErrors()) {
            certificate.markValidated();
        }
        return result;
    }

    @Transactional
    public Certificate generate(UUID certificateId) {
        Certificate certificate = getById(certificateId);
        if (!certificate.canBeGenerated()) {
            throw new ForbiddenOperationException("Формирование PDF доступно только для аттестата в статусе DRAFT или VALIDATED");
        }

        ValidationResult result = validationService.validate(certificate.getStudent());
        if (result.hasErrors()) {
            throw new ValidationException("Невозможно сформировать PDF: данные учащегося не прошли проверку", result.errors());
        }

        String path = pdfService.generate(certificate);
        certificate.markGenerated(path);
        auditService.log("CERTIFICATE_GENERATED", "Certificate", certificate.getId().toString(), path);
        return certificate;
    }

    @Transactional
    public Certificate issue(UUID certificateId) {
        Certificate certificate = getById(certificateId);
        if (!certificate.canBeIssued()) {
            throw new ForbiddenOperationException("Выдача возможна только для аттестата в статусе GENERATED");
        }
        certificate.markIssued();
        auditService.log("CERTIFICATE_ISSUED", "Certificate", certificate.getId().toString(), certificate.getCertificateNumber());
        return certificate;
    }

    @Transactional
    public Certificate cancel(UUID certificateId, String reason) {
        Certificate certificate = getById(certificateId);
        if (!certificate.canBeCancelled()) {
            throw new ForbiddenOperationException("Выданный аттестат не может быть отменен");
        }
        certificate.markCancelled();
        auditService.log("CERTIFICATE_CANCELLED", "Certificate", certificate.getId().toString(), reason);
        return certificate;
    }

    @Transactional(readOnly = true)
    public Certificate getById(UUID id) {
        return certificateRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Аттестат не найден: " + id));
    }

    @Transactional(readOnly = true)
    public List<Certificate> findAll() {
        return certificateRepository.findAll();
    }
}
