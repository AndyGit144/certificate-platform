package ru.education.certificateplatform.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.education.certificateplatform.dto.grade.GradeImportRequest;
import ru.education.certificateplatform.entity.FinalGrade;
import ru.education.certificateplatform.entity.Student;
import ru.education.certificateplatform.entity.Subject;
import ru.education.certificateplatform.exception.EntityNotFoundException;
import ru.education.certificateplatform.exception.ValidationException;
import ru.education.certificateplatform.repository.FinalGradeRepository;
import ru.education.certificateplatform.repository.SubjectRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class GradeService {

    private final FinalGradeRepository finalGradeRepository;
    private final SubjectRepository subjectRepository;
    private final StudentService studentService;
    private final AuditService auditService;

    @Transactional
    public List<FinalGrade> importGrades(GradeImportRequest request) {
        Student student = studentService.getById(request.studentId());

        List<String> errors = new ArrayList<>();
        List<FinalGrade> result = new ArrayList<>();

        for (var item : request.grades()) {
            Subject subject = subjectRepository.findById(item.subjectId())
                    .orElseThrow(() -> new EntityNotFoundException("Предмет не найден: " + item.subjectId()));

            FinalGrade grade = finalGradeRepository.findByStudentIdAndSubjectId(student.getId(), subject.getId())
                    .orElseGet(() -> FinalGrade.builder().student(student).subject(subject).build());
            grade.setGradeValue(item.gradeValue());

            if (!grade.isValueAllowed()) {
                errors.add("Недопустимое значение отметки по предмету \"" + subject.getName() + "\": " + item.gradeValue());
                continue;
            }
            result.add(grade);
        }

        if (!errors.isEmpty()) {
            throw new ValidationException("Ошибки импорта итоговых отметок", errors);
        }

        List<FinalGrade> saved = finalGradeRepository.saveAll(result);
        auditService.log("GRADES_IMPORTED", "Student", student.getId().toString(), saved.size() + " отметок");
        return saved;
    }

    @Transactional(readOnly = true)
    public List<FinalGrade> findByStudent(UUID studentId) {
        return finalGradeRepository.findByStudentId(studentId);
    }

    @Transactional
    public FinalGrade updateGrade(UUID gradeId, String newValue) {
        FinalGrade grade = finalGradeRepository.findById(gradeId)
                .orElseThrow(() -> new EntityNotFoundException("Отметка не найдена: " + gradeId));
        grade.setGradeValue(newValue);
        if (!grade.isValueAllowed()) {
            throw new ValidationException("Недопустимое значение отметки", List.of("Значение: " + newValue));
        }
        auditService.log("GRADE_UPDATED", "FinalGrade", gradeId.toString(), newValue);
        return grade;
    }
}
