package ru.education.certificateplatform.service;

import com.lowagie.text.*;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ru.education.certificateplatform.entity.Certificate;
import ru.education.certificateplatform.entity.CurriculumSubject;
import ru.education.certificateplatform.entity.FinalGrade;
import ru.education.certificateplatform.exception.PdfGenerationException;
import ru.education.certificateplatform.repository.CurriculumSubjectRepository;
import ru.education.certificateplatform.repository.FinalGradeRepository;

import java.awt.Color;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Формирование PDF-документа аттестата по данным учащегося
 * и итоговым отметкам, с использованием библиотеки OpenPDF.
 */
@Service
@RequiredArgsConstructor
public class PdfService {

    private final CurriculumSubjectRepository curriculumSubjectRepository;
    private final FinalGradeRepository finalGradeRepository;

    @Value("${app.storage.certificates-dir:./storage/certificates}")
    private String storageDir;

    public String generate(Certificate certificate) {
        var student = certificate.getStudent();
        try {
            Files.createDirectories(Path.of(storageDir));
        } catch (IOException e) {
            throw new PdfGenerationException("Не удалось создать каталог хранения PDF", e);
        }

        String fileName = certificate.getCertificateNumber().replaceAll("[^A-Za-z0-9_-]", "_") + ".pdf";
        Path filePath = Path.of(storageDir, fileName);

        Document document = new Document(PageSize.A4);
        try (FileOutputStream fos = new FileOutputStream(filePath.toFile())) {
            PdfWriter.getInstance(document, fos);
            document.open();

            Font titleFont = new Font(Font.HELVETICA, 18, Font.BOLD);
            Font headerFont = new Font(Font.HELVETICA, 12, Font.BOLD);
            Font bodyFont = new Font(Font.HELVETICA, 11, Font.NORMAL);

            Paragraph title = new Paragraph("АТТЕСТАТ", titleFont);
            title.setAlignment(Element.ALIGN_CENTER);
            document.add(title);

            document.add(new Paragraph(" "));
            document.add(new Paragraph("Регистрационный номер: " + certificate.getCertificateNumber(), bodyFont));
            document.add(new Paragraph("Учащийся: " + student.fullName(), headerFont));
            document.add(new Paragraph("Дата рождения: " +
                    student.getBirthDate().format(DateTimeFormatter.ofPattern("dd.MM.yyyy")), bodyFont));
            document.add(new Paragraph("Образовательная программа: " + student.getProgram().getName(), bodyFont));
            document.add(new Paragraph(" "));

            PdfPTable table = new PdfPTable(2);
            table.setWidthPercentage(100);
            table.addCell(headerCell("Предмет", headerFont));
            table.addCell(headerCell("Итоговая отметка", headerFont));

            List<CurriculumSubject> curriculum = curriculumSubjectRepository
                    .findByProgramIdOrderByDisplayOrderAsc(student.getProgram().getId());
            List<FinalGrade> grades = finalGradeRepository.findByStudentId(student.getId());
            Map<String, String> gradeBySubject = grades.stream()
                    .collect(Collectors.toMap(g -> g.getSubject().getId().toString(), FinalGrade::getGradeValue));

            for (CurriculumSubject cs : curriculum) {
                table.addCell(new PdfPCell(new Phrase(cs.getSubject().getName(), bodyFont)));
                String value = gradeBySubject.getOrDefault(cs.getSubject().getId().toString(), "-");
                table.addCell(new PdfPCell(new Phrase(value, bodyFont)));
            }

            document.add(table);
            document.add(new Paragraph(" "));
            document.add(new Paragraph("Дата выдачи: " +
                    java.time.LocalDate.now().format(DateTimeFormatter.ofPattern("dd.MM.yyyy")), bodyFont));

        } catch (DocumentException | IOException e) {
            throw new PdfGenerationException("Ошибка при формировании PDF аттестата", e);
        } finally {
            if (document.isOpen()) {
                document.close();
            }
        }

        return filePath.toString();
    }

    private PdfPCell headerCell(String text, Font font) {
        PdfPCell cell = new PdfPCell(new Phrase(text, font));
        cell.setBackgroundColor(new Color(230, 230, 230));
        return cell;
    }
}
