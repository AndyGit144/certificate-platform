package ru.education.certificateplatform.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.education.certificateplatform.dto.program.ProgramCreateRequest;
import ru.education.certificateplatform.entity.CurriculumSubject;
import ru.education.certificateplatform.entity.EducationProgram;
import ru.education.certificateplatform.entity.Subject;
import ru.education.certificateplatform.exception.EntityNotFoundException;
import ru.education.certificateplatform.repository.CurriculumSubjectRepository;
import ru.education.certificateplatform.repository.ProgramRepository;
import ru.education.certificateplatform.repository.SubjectRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class ProgramService {

    private final ProgramRepository programRepository;
    private final SubjectRepository subjectRepository;
    private final CurriculumSubjectRepository curriculumSubjectRepository;
    private final AuditService auditService;

    @Transactional
    public EducationProgram create(ProgramCreateRequest request) {
        EducationProgram program = EducationProgram.builder()
                .name(request.name())
                .level(request.level())
                .build();
        EducationProgram saved = programRepository.save(program);

        if (request.subjects() != null) {
            List<CurriculumSubject> curriculum = new ArrayList<>();
            for (var item : request.subjects()) {
                Subject subject = resolveSubject(item.subjectId(), item.subjectName());
                curriculum.add(CurriculumSubject.builder()
                        .program(saved)
                        .subject(subject)
                        .mandatory(item.mandatory())
                        .displayOrder(item.displayOrder())
                        .build());
            }
            curriculumSubjectRepository.saveAll(curriculum);
            saved.setCurriculumSubjects(curriculum);
        }

        auditService.log("PROGRAM_CREATED", "EducationProgram", saved.getId().toString(), saved.getName());
        return saved;
    }

    private Subject resolveSubject(UUID subjectId, String subjectName) {
        if (subjectId != null) {
            return subjectRepository.findById(subjectId)
                    .orElseThrow(() -> new EntityNotFoundException("Предмет не найден: " + subjectId));
        }
        return subjectRepository.findByName(subjectName)
                .orElseGet(() -> subjectRepository.save(Subject.builder().name(subjectName).build()));
    }

    @Transactional(readOnly = true)
    public EducationProgram getById(UUID id) {
        return programRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Образовательная программа не найдена: " + id));
    }

    @Transactional(readOnly = true)
    public List<EducationProgram> findAll() {
        return programRepository.findAll();
    }

    @Transactional
    public void delete(UUID id) {
        EducationProgram program = getById(id);
        programRepository.delete(program);
        auditService.log("PROGRAM_DELETED", "EducationProgram", id.toString(), null);
    }
}
