package ru.education.certificateplatform.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.education.certificateplatform.dto.student.StudentCreateRequest;
import ru.education.certificateplatform.dto.student.StudentUpdateRequest;
import ru.education.certificateplatform.entity.EducationProgram;
import ru.education.certificateplatform.entity.Student;
import ru.education.certificateplatform.exception.DuplicateEntityException;
import ru.education.certificateplatform.exception.EntityNotFoundException;
import ru.education.certificateplatform.repository.StudentRepository;

import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class StudentService {

    private final StudentRepository studentRepository;
    private final ProgramService programService;
    private final AuditService auditService;

    @Transactional
    public Student create(StudentCreateRequest request) {
        if (studentRepository.existsByPersonalNumber(request.personalNumber())) {
            throw new DuplicateEntityException("Учащийся с личным номером уже существует: " + request.personalNumber());
        }
        EducationProgram program = programService.getById(request.programId());

        Student student = Student.builder()
                .lastName(request.lastName())
                .firstName(request.firstName())
                .middleName(request.middleName())
                .birthDate(request.birthDate())
                .personalNumber(request.personalNumber())
                .program(program)
                .archived(false)
                .build();

        Student saved = studentRepository.save(student);
        auditService.log("STUDENT_CREATED", "Student", saved.getId().toString(), saved.fullName());
        return saved;
    }

    @Transactional
    public Student update(UUID id, StudentUpdateRequest request) {
        Student student = getById(id);
        EducationProgram program = programService.getById(request.programId());

        student.setLastName(request.lastName());
        student.setFirstName(request.firstName());
        student.setMiddleName(request.middleName());
        student.setBirthDate(request.birthDate());
        student.setProgram(program);

        auditService.log("STUDENT_UPDATED", "Student", student.getId().toString(), student.fullName());
        return student;
    }

    @Transactional(readOnly = true)
    public Student getById(UUID id) {
        return studentRepository.findWithProgramById(id)
                .orElseThrow(() -> new EntityNotFoundException("Учащийся не найден: " + id));
    }

    @Transactional(readOnly = true)
    public List<Student> findAll(boolean includeArchived) {
        return includeArchived ? studentRepository.findAll() : studentRepository.findByArchivedFalse();
    }

    @Transactional
    public void archive(UUID id) {
        Student student = getById(id);
        student.setArchived(true);
        auditService.log("STUDENT_ARCHIVED", "Student", id.toString(), null);
    }
}
