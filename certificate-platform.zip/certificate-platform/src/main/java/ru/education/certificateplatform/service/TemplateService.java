package ru.education.certificateplatform.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.education.certificateplatform.dto.certificate.TemplateCreateRequest;
import ru.education.certificateplatform.entity.CertificateTemplate;
import ru.education.certificateplatform.exception.EntityNotFoundException;
import ru.education.certificateplatform.repository.CertificateTemplateRepository;

import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class TemplateService {

    private final CertificateTemplateRepository templateRepository;
    private final AuditService auditService;

    @Transactional
    public CertificateTemplate create(TemplateCreateRequest request) {
        int nextVersion = 1;
        CertificateTemplate template = CertificateTemplate.builder()
                .name(request.name())
                .layoutPath(request.layoutPath())
                .version(nextVersion)
                .active(false)
                .build();
        CertificateTemplate saved = templateRepository.save(template);
        auditService.log("TEMPLATE_CREATED", "CertificateTemplate", saved.getId().toString(), saved.getName());
        return saved;
    }

    @Transactional
    public CertificateTemplate activate(UUID id) {
        templateRepository.findByActiveTrue().ifPresent(current -> current.setActive(false));
        CertificateTemplate template = getById(id);
        template.setActive(true);
        auditService.log("TEMPLATE_ACTIVATED", "CertificateTemplate", id.toString(), null);
        return template;
    }

    @Transactional(readOnly = true)
    public CertificateTemplate getById(UUID id) {
        return templateRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Шаблон аттестата не найден: " + id));
    }

    @Transactional(readOnly = true)
    public List<CertificateTemplate> findAll() {
        return templateRepository.findAll();
    }
}
