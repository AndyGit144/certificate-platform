package ru.education.certificateplatform.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.education.certificateplatform.entity.User;
import ru.education.certificateplatform.exception.EntityNotFoundException;
import ru.education.certificateplatform.repository.UserRepository;

import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class UserManagementService {

    private final UserRepository userRepository;
    private final AuditService auditService;

    @Transactional(readOnly = true)
    public List<User> findAll() {
        return userRepository.findAll();
    }

    @Transactional
    public User setActive(UUID id, boolean active) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Пользователь не найден: " + id));
        user.setActive(active);
        auditService.log(active ? "USER_ACTIVATED" : "USER_DEACTIVATED", "User", id.toString(), null);
        return user;
    }
}
