package ru.education.certificateplatform.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.education.certificateplatform.entity.CurriculumSubject;
import ru.education.certificateplatform.entity.FinalGrade;
import ru.education.certificateplatform.entity.Student;
import ru.education.certificateplatform.entity.ValidationResult;
import ru.education.certificateplatform.repository.CurriculumSubjectRepository;
import ru.education.certificateplatform.repository.FinalGradeRepository;

import java.util.Map;
import java.util.stream.Collectors;

/**
 * Проверка данных учащегося перед печатью аттестата:
 * - полнота персональных сведений;
 * - наличие итоговых отметок по всем обязательным предметам программы;
 * - корректность значений отметок.
 */
@Service
@RequiredArgsConstructor
public class ValidationService {

    private final CurriculumSubjectRepository curriculumSubjectRepository;
    private final FinalGradeRepository finalGradeRepository;
    private final AuditService auditService;

    @Transactional(readOnly = true)
    public ValidationResult validate(Student student) {
        ValidationResult result = new ValidationResult();

        if (!student.hasCompletePersonalData()) {
            result.addError("Не заполнены обязательные персональные сведения учащегося");
        }

        var curriculum = curriculumSubjectRepository.findByProgramIdOrderByDisplayOrderAsc(student.getProgram().getId());
        var grades = finalGradeRepository.findByStudentId(student.getId());
        Map<String, FinalGrade> gradesBySubject = grades.stream()
                .collect(Collectors.toMap(g -> g.getSubject().getId().toString(), g -> g));

        for (CurriculumSubject cs : curriculum) {
            if (!cs.isMandatory()) {
                continue;
            }
            FinalGrade grade = gradesBySubject.get(cs.getSubject().getId().toString());
            if (grade == null) {
                result.addError("Отсутствует итоговая отметка по обязательному предмету \"" + cs.getSubject().getName() + "\"");
            } else if (!grade.isValueAllowed()) {
                result.addError("Некорректное значение отметки по предмету \"" + cs.getSubject().getName() + "\": " + grade.getGradeValue());
            }
        }

        if (curriculum.isEmpty()) {
            result.addWarning("Для образовательной программы учащегося не задан перечень предметов");
        }

        String status = result.hasErrors() ? "VALIDATION_FAILED" : "VALIDATION_PASSED";
        auditService.log(status, "Student", student.getId().toString(),
                "errors=" + result.errors().size() + "; warnings=" + result.warnings().size());

        return result;
    }
}
