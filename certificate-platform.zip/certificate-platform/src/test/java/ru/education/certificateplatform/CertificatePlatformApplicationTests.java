package ru.education.certificateplatform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest
@ActiveProfiles("local")
class CertificatePlatformApplicationTests {

    @Test
    void contextLoads() {
    }
}
